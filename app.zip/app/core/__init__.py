"""Core settings and security utilities."""

