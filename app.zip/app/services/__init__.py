"""Domain services (email, payments, etc.)."""

