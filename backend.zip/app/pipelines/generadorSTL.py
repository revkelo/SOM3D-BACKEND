from fastapi import APIRouter, UploadFile, File, HTTPException, Query
from fastapi.responses import FileResponse
from pathlib import Path
import shutil, uuid, tempfile, zipfile

# Tu pipeline:
from app.pipelines.segmentor import run_segmentation
from app.pipelines.generadorSTL import NiiToStlConverter

router = APIRouter(prefix="/pipeline", tags=["pipeline"])

@router.post("/dicom-to-stl")
async def dicom_to_stl(
    file: UploadFile = File(..., description="ZIP con serie DICOM (recomendado) o .dcm de demo"),
    task: str = Query("total", description="Tarea TotalSegmentator: total, total_mr, body, etc."),
    # Estos params opcionales mapean a tu clase NiiToStlConverter
    threshold_min: int = 150,
    threshold_max: int = 3075,
    keep_ratio: float = 0.5,
    laplacian_lambda: float = 0.5,
    laplacian_iters: int = 10,
    min_voxels: int = 50,
    downsample_factor: int = 2
):
    # Persistimos SOLO STL en media/stl/(originales|reducidos)
    stl_root = Path("media/stl")
    stl_root.mkdir(parents=True, exist_ok=True)

    stem = (Path(file.filename).stem or "dicom")[:64]
    uid = uuid.uuid4().hex[:8]
    name_tag = f"{stem}-{uid}"

    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        case_dir = td_path / "case"; case_dir.mkdir(parents=True, exist_ok=True)
        out_case = td_path / "nifti"; out_case.mkdir(parents=True, exist_ok=True)
        upload_path = td_path / Path(file.filename).name

        # Guarda upload
        with upload_path.open("wb") as f:
            shutil.copyfileobj(file.file, f)

        # Normaliza: ZIP -> extraer; DCM -> copiar a carpeta
        suf = upload_path.suffix.lower()
        if suf == ".zip":
            try:
                with zipfile.ZipFile(upload_path, "r") as z:
                    z.extractall(case_dir)
            except Exception:
                raise HTTPException(400, "El ZIP no es válido o está corrupto")
        elif suf == ".dcm":
            shutil.copy(upload_path, case_dir / upload_path.name)
        else:
            raise HTTPException(400, "Sube .zip (serie DICOM) o .dcm")

        # 1) SEGMENTACIÓN → out_case (NIfTI)
        try:
            run_segmentation(
                input_path=case_dir,
                output_path=out_case,
                task=task,
                force_cpu=False,
                keep_temp=False,
                extra_args=None
            )
        except Exception as e:
            raise HTTPException(400, f"Fallo segmentación: {e}")

        # 2) Elegimos un NIfTI de salida
        nii_files = list(out_case.rglob("*.nii.gz")) + list(out_case.rglob("*.nii"))
        if not nii_files:
            raise HTTPException(404, "No se encontró salida NIfTI de la segmentación")
        nii_path = nii_files[0]

        # 3) Convertir con TU clase (exporta a media/stl/originales & reducidos)
        conv = NiiToStlConverter(
            input_dir=str(out_case),
            output_root=str(stl_root),
            label_value=None,
            threshold_min=threshold_min,
            threshold_max=threshold_max,
            keep_ratio=keep_ratio,
            laplacian_lambda=laplacian_lambda,
            laplacian_iters=laplacian_iters,
            min_voxels=min_voxels,
            downsample_factor=downsample_factor,
            recursive=False,
        )

        # Forzamos el basename consistente (tu clase ya lo calcula desde el .nii)
        res = conv.process_one_file(str(nii_path))
        if not res.get("success"):
            raise HTTPException(400, f"Conversión falló: {res.get('message','error desconocido')}")

        # Paths absolutos → nombres y URLs
        stl_abs = Path(res["stl"])            # media/stl/originales/<name>.stl
        stl_red_abs = Path(res["stl_reduced"])# media/stl/reducidos/<name>-reducido.stl

        return {
            "ok": True,
            "nifti": Path(nii_path).name,
            "stl_original": stl_abs.name,
            "stl_reducido": stl_red_abs.name,
            "url_original": f"/pipeline/stl/originales/{stl_abs.name}",
            "url_reducido": f"/pipeline/stl/reducidos/{stl_red_abs.name}",
            "metodo_reduccion": res.get("method"),
            "voxels_mask": res.get("voxels_mask"),
        }

@router.get("/stl/{kind}/{filename}")
def download_stl(kind: str, filename: str):
    """
    kind: 'originales' o 'reducidos'
    """
    if kind not in {"originales", "reducidos"}:
        raise HTTPException(400, "kind debe ser 'originales' o 'reducidos'")
    path = Path("media/stl") / kind / filename
    if not path.exists():
        raise HTTPException(404, "STL no encontrado")
    return FileResponse(path, media_type="model/stl", filename=path.name)
