from fastapi import APIRouter, UploadFile, File, HTTPException, Query
from fastapi.responses import FileResponse
from pathlib import Path
import shutil, uuid, tempfile, zipfile
from typing import Optional

# IMPORTA TU PIPELINE ORIGINAL
# Asegúrate de que en segmentor.py exista la función `run_segmentation`
# y en generadorSTL.py exista la clase `NiiToStlConverter` con método estático `convert(...)`.
from app.pipelines.segmentor import run_segmentation
from app.pipelines.generadorSTL import NiiToStlConverter

router = APIRouter(prefix="/pipeline", tags=["pipeline"])

@router.post("/dicom-to-stl")
async def dicom_to_stl(
    file: UploadFile = File(..., description="ZIP con serie DICOM (recomendado) o .dcm de demo"),
    task: str = Query("total", description="Tarea TotalSegmentator: total, total_mr, body, etc."),
    iso_value: int = Query(350, description="Marching Cubes ISO si el NIfTI no es binario")
):
    # Persistimos solo el STL final; lo demás en temporales
    out_stl_dir = Path("media/stl")
    out_stl_dir.mkdir(parents=True, exist_ok=True)

    stem = (Path(file.filename).stem or "dicom")[:64]
    uid = uuid.uuid4().hex[:8]
    stl_name = f"{stem}-{uid}.stl"
    stl_path = out_stl_dir / stl_name

    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        case_dir = td_path / "case"; case_dir.mkdir(parents=True, exist_ok=True)
        out_case = td_path / "nifti"; out_case.mkdir(parents=True, exist_ok=True)
        upload_path = td_path / Path(file.filename).name

        # Guardar upload
        with upload_path.open("wb") as f:
            shutil.copyfileobj(file.file, f)

        # Normalizar a carpeta con la serie
        if upload_path.suffix.lower() == ".zip":
            try:
                with zipfile.ZipFile(upload_path, "r") as z:
                    z.extractall(case_dir)
            except Exception:
                raise HTTPException(400, "El ZIP no es válido o está corrupto")
        elif upload_path.suffix.lower() == ".dcm":
            shutil.copy(upload_path, case_dir / upload_path.name)
        else:
            raise HTTPException(400, "Sube .zip (serie DICOM) o .dcm")

        # 1) SEGMENTACIÓN (usa tu segmentor.py)
        try:
            run_segmentation(
                input_path=case_dir,
                output_path=out_case,
                task=task,
                force_cpu=False,   # tu cuda.py decide backend
                keep_temp=False,
                extra_args=None
            )
        except Exception as e:
            raise HTTPException(400, f"Fallo segmentación: {e}")

        # 2) Elegir un NIfTI para convertir a STL
        nii_files = list(out_case.rglob("*.nii.gz")) + list(out_case.rglob("*.nii"))
        if not nii_files:
            raise HTTPException(404, "No se encontró salida NIfTI de la segmentación")
        nii_path = nii_files[0]

        # 3) CONVERSIÓN a STL (usa tu generadorSTL.py)
        try:
            # Si tu convert permite más params, pásalos aquí
            NiiToStlConverter.convert(str(nii_path), str(stl_path), iso_value=iso_value)
        except Exception as e:
            raise HTTPException(400, f"Fallo conversión NIfTI→STL: {e}")

    return {"ok": True, "stl_file": stl_name}

@router.get("/stl/{filename}")
def download_stl(filename: str):
    path = Path("media/stl") / filename
    if not path.exists():
        raise HTTPException(404, "STL no encontrado")
    return FileResponse(path, media_type="model/stl", filename=path.name)
